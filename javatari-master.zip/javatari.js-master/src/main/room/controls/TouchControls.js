// Copyright 2015 by Paulo Augusto Peccin. See license.txt distributed with this file.

// General, immutable info about host Touch Buttons

jt.TouchControls = {

    buttons: [ "T_B", "T_A" ]       // Specific order for vertical in-line placement on the screen

};
